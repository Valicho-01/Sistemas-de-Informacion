<?php
namespace Tests\Feature;
use Tests\TestCase;use Illuminate\Foundation\Testing\RefreshDatabase;use App\Services\{Validacion,Pedidos,Importe};
class AceptacionTest extends TestCase {use RefreshDatabase;public function test_diez_casos():void {$this->seed();foreach(app(Validacion::class)->ejecutar() as $r)$this->assertTrue($r['ok'],$r['nombre'].' '.$r['detalle']);}public function test_iteracion_uno():void {$this->seed();$s=app(Pedidos::class);$p=$s->agregar($s->nuevo(1),'P01',5);$this->assertEquals(2500,$p->total);}public function test_redondeo():void {$this->assertSame(201,Importe::calcular(2005,2)['descuento']);}public function test_pagina():void {$this->seed();$this->get('/')->assertOk()->assertSee('Catálogo de productos');$this->get('/pruebas')->assertOk();}}
