<?php
namespace App\Http\Controllers;
use App\Models\{Pedido,Producto};use App\Services\{Pedidos,Validacion};use Illuminate\Http\Request;use DomainException;
class CafeController {
 private function actual(Request $r,Pedidos $s):Pedido {$p=Pedido::find($r->session()->get('pedido'));if(!$p){$p=$s->nuevo();$r->session()->put('pedido',$p->id);}return $p;}
 public function index(Request $r,Pedidos $s){return view('cafe',['pedido'=>$this->actual($r,$s)->load('detalles.producto'),'productos'=>Producto::orderBy('codigo')->get()]);}
 public function agregar(Request $r,Pedidos $s){$v=$r->validate(['codigo'=>'required|string','cantidad'=>'required']);try{$s->agregar($this->actual($r,$s),$v['codigo'],$v['cantidad']);return back()->with('mensaje','Producto agregado.');}catch(DomainException $e){return back()->withErrors($e->getMessage());}}
 public function confirmar(Request $r,Pedidos $s){try{$s->confirmar($this->actual($r,$s));return back()->with('mensaje','Pedido confirmado.');}catch(DomainException $e){return back()->withErrors($e->getMessage());}}
 public function nuevo(Request $r,Pedidos $s){$v=$r->validate(['iteracion'=>'required|in:1,2']);$r->session()->put('pedido',$s->nuevo((int)$v['iteracion'])->id);return redirect('/');}
 public function pruebas(){return view('pruebas',['resultados'=>null]);}
 public function ejecutar(Validacion $v){return view('pruebas',['resultados'=>$v->ejecutar()]);}
}
