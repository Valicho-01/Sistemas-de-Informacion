<?php
namespace App\Models;
class Producto extends \Illuminate\Database\Eloquent\Model {protected $table='productos'; protected $guarded=[]; public $timestamps=false;  }