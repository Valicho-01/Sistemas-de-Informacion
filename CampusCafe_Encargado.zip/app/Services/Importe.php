<?php
namespace App\Services;
class Importe {public static function calcular(int $subtotal,int $iteracion):array {$d=$iteracion===2 && $subtotal>=2000 ? intdiv($subtotal+5,10):0;return ['subtotal'=>$subtotal,'descuento'=>$d,'total'=>$subtotal-$d];}}
