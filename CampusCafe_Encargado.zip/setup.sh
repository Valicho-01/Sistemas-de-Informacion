#!/usr/bin/env bash
set -e
mkdir -p bootstrap/cache storage/framework/{sessions,views,cache} storage/logs
if ! php -m | grep -qi pdo_sqlite; then sudo apt-get update && sudo apt-get install -y libsqlite3-dev && sudo docker-php-ext-install pdo_sqlite; fi
[ -f .env ] || cp .env.example .env
[ -f database/database.sqlite ] || touch database/database.sqlite
composer install --no-interaction
if ! grep -q '^APP_KEY=base64:' .env; then php artisan key:generate; fi
php artisan migrate --seed --force
