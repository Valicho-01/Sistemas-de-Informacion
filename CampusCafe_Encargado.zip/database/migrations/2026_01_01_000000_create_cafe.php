<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {
 Schema::create('productos',function(Blueprint $t){$t->id();$t->string('codigo')->unique();$t->string('nombre');$t->unsignedInteger('precio');});
 Schema::create('pedidos',function(Blueprint $t){$t->id();$t->unsignedTinyInteger('iteracion');$t->string('estado')->default('abierto');$t->unsignedInteger('subtotal')->default(0);$t->unsignedInteger('descuento')->default(0);$t->unsignedInteger('total')->default(0);$t->timestamps();});
 Schema::create('detalle_pedido',function(Blueprint $t){$t->id();$t->foreignId('pedido_id')->constrained('pedidos')->cascadeOnDelete();$t->foreignId('producto_id')->constrained('productos');$t->unsignedInteger('cantidad');$t->unsignedInteger('precio_unitario');$t->unique(['pedido_id','producto_id']);});
 }
 public function down(): void {Schema::dropIfExists('detalle_pedido');Schema::dropIfExists('pedidos');Schema::dropIfExists('productos');}
};
